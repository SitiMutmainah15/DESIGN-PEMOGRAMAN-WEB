<?php
include 'koneksi.php';
session_start();

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

    $result = pg_query_params($conn, "SELECT * FROM users WHERE username=$1", [$user]);
    $data = pg_fetch_assoc($result);

    if ($data && password_verify($pass, $data['password'])) {
        $_SESSION['admin'] = $data['username'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="card shadow-sm p-4" style="max-width:400px;margin:auto;">
    <h3 class="text-center mb-3">Login Admin</h3>
    <?php if ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label>Username</label>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button class="btn btn-primary w-100">Masuk</button>
      <div class="text-center mt-3">
        <a href="register.php">Belum punya akun? Daftar</a>
      </div>
    </form>
  </div>
</div>

</body>
</html>
