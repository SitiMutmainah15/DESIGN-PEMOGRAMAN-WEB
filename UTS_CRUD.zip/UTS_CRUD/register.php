<?php
include 'koneksi.php';
session_start();

$msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if ($username === '' || $password === '') {
        $msg = "Semua field wajib diisi!";
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT); // enkripsi password

        $check = pg_query_params($conn, "SELECT * FROM users WHERE username=$1", [$username]);
        if (pg_num_rows($check) > 0) {
            $msg = "Username sudah digunakan!";
        } else {
            $query = pg_query_params($conn, "INSERT INTO users (username, password) VALUES ($1, $2)", [$username, $hashed]);
            if ($query) {
                $msg = "Registrasi berhasil! Silakan login.";
            } else {
                $msg = "Terjadi kesalahan: " . pg_last_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Register Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="card shadow-sm p-4" style="max-width:400px;margin:auto;">
    <h3 class="text-center mb-3">Register Admin</h3>
    <?php if ($msg): ?>
      <div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label>Username</label>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button class="btn btn-primary w-100">Daftar</button>
      <div class="text-center mt-3">
        <a href="login.php">Sudah punya akun? Login</a>
      </div>
    </form>
  </div>
</div>

</body>
</html>
