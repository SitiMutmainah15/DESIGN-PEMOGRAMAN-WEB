<?php
include 'auth_check.php';
include 'koneksi.php';

//cek apakah form sdh dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  //isi form ambil dari ini
  $nama = $_POST['nama'];
  $kategori = $_POST['kategori'];
  $deskripsi = $_POST['deskripsi'];
  $bahan = $_POST['bahan'];
  $langkah = $_POST['langkah'];
  $gambar = $_FILES['gambar']['name'];
//buat tujuan upload gambar
  if ($gambar) {
    $target = "upload/" . basename($gambar);
    move_uploaded_file($_FILES //memindah file ke folder upload
    
    ['gambar']['tmp_name'], $target);
  }

  //mengirim data ke db 
  $query = "INSERT INTO menu (nama, kategori, deskripsi, gambar, bahan, langkah)
            VALUES ('$nama', '$kategori', '$deskripsi', '$gambar', '$bahan', '$langkah')";

  //jalankan perintah sql
  pg_query($conn, $query);
  header("Location: index.php"); //jk berhasil lgsg ke index.php
  exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Menu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container my-5">
    <h3>Tambah Menu Baru</h3>
    <form method="POST" enctype="multipart/form-data">
      <label>Nama Menu</label>
      <input type="text" name="nama" class="form-control" required>

      <label class="mt-3">Kategori</label>
      <input type="text" name="kategori" class="form-control" required>

      <label class="mt-3">Deskripsi</label>
      <textarea name="deskripsi" class="form-control" required></textarea>

      <label class="mt-3">Bahan-Bahan</label>
      <textarea name="bahan" class="form-control" rows="5" placeholder="Contoh: 200 gr ayam, 2 wortel, 1 blok kari..." required></textarea>

      <label class="mt-3">Langkah Memasak</label>
      <textarea name="langkah" class="form-control" rows="5"></textarea>

      <label class="mt-3">Gambar</label>
      <input type="file" name="gambar" class="form-control mb-3">

      <button class="btn btn-success">Simpan</button>
      <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
  </div>
</body>
</html>
